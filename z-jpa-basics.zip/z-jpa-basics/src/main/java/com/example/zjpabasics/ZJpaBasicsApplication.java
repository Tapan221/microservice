package com.example.zjpabasics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZJpaBasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZJpaBasicsApplication.class, args);
	}

}
