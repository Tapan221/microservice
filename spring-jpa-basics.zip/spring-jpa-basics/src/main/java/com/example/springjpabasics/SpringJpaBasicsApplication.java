package com.example.springjpabasics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaBasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaBasicsApplication.class, args);
	}

}
