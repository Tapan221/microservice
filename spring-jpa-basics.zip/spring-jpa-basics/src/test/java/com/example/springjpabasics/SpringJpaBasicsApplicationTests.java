package com.example.springjpabasics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaBasicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
