package com.example.vmwarenumbergenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VmwareNumberGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
