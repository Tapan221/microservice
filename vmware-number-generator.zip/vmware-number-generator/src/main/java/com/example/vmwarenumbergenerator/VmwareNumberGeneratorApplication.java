package com.example.vmwarenumbergenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VmwareNumberGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(VmwareNumberGeneratorApplication.class, args);
	}

}
